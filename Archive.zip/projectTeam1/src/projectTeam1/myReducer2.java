package projectTeam1;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer2 extends Reducer<Text, IntWritable, Text, Text>{
	public void reduce(Text k, Iterable<IntWritable> v, Context c) throws IOException, InterruptedException{
		int ww, emp=0, unemp=0;
		for(IntWritable x : v){
			ww = Integer.parseInt(x.toString());
			if(ww<=0)
				unemp++;
			else
				emp++;
		}
		c.write(new Text(k), new Text("Employed : " +emp+"UnEmployed : " +unemp ));
	}
}
