package projectTeam1;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer3 extends Reducer<Text, IntWritable, Text, NullWritable>{
	public void reduce(Text k, Iterable<IntWritable> v,Context c) throws IOException, InterruptedException{
		int cnt=0;
		for(IntWritable x: v){
			cnt++;
		}
		c.write(new Text(" The total number of people having " +k +" education are "+cnt), null);
	}

}
