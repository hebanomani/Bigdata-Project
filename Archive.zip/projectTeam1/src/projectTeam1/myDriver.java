package projectTeam1;

import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class myDriver {
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
		@SuppressWarnings("resource")
		Scanner src = new Scanner(System.in);
		System.out.println("Enter your choice : \n 1. Task 1 \n 2. Task 2 \n 3. Task 3");
		int ch= src.nextInt();
		int min,max;
		switch(ch){
		case 1: {
			Configuration conf = new Configuration();
			Job j = new Job(conf, "Team 1 Task 1");
			FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(myDriver.class);
			j.setMapperClass(myMapper.class);
			j.setReducerClass(myReducer.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(IntWritable.class);
			j.setInputFormatClass(myInputFormat.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
			Path newpath = new Path(args[1]);
			if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
			Path localfilepath = new Path("/home/cloudera/Desktop/Team1/Task1");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, localfilepath);
			}
			break;
		}
		case 2: {
			Configuration conf = new Configuration();
			Job j = new Job(conf, "Team 1 Task 2");
			FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(myDriver.class);
			j.setMapperClass(myMapper2.class);
			j.setReducerClass(myReducer2.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(IntWritable.class);
			j.setInputFormatClass(myInputFormat.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
			Path newpath = new Path(args[1]);
			if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
			Path localfilepath = new Path("/home/cloudera/Desktop/Team1/Task2");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, localfilepath);
			}
			break;
		}
		
		case 3:{
			Configuration conf = new Configuration();
			Job j = new Job(conf, "Team 1 Task 3");
			do{
			System.out.println("Enter the minimum and maximum age :");
			min = src.nextInt();
			max = src.nextInt();
			}while(min<18 || max >60);
			conf.setInt("min", min);
			conf.setInt("max", max);
			FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(myDriver.class);
			j.setMapperClass(myMapper3.class);
			j.setReducerClass(myReducer3.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(IntWritable.class);
			j.setInputFormatClass(myInputFormat.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
			Path newpath = new Path(args[1]);
			if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
			Path localfilepath = new Path("/home/cloudera/Desktop/Team1/Task2");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, localfilepath);
			}
			break;
		}
		
		default:
			System.out.println("You have entered wrong choice");
		
			
		}
	}

}
