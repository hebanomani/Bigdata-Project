 package projectTeam1;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<myKey, myValue, Text, IntWritable> {
	public void map(myKey k , myValue v ,Context c) throws IOException, InterruptedException{
		String gen = v.getGender().toString().trim();
		String edu = v.getEducation().toString().trim();
		c.write(new Text(gen+" "+edu), new IntWritable(1));
	}

}
