package projectTeam1;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper2 extends Mapper<myKey, myValue, Text, IntWritable> {
	
	public void map(myKey k , myValue v, Context c) throws IOException, InterruptedException{
		String edu = v.getEducation().toString().trim();
		int ww =Integer.parseInt(v.getWW().toString().trim());
		c.write(new Text(edu), new IntWritable(ww));
	}

}
