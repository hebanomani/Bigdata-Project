package projectTeam1;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper3 extends Mapper<myKey, myValue, Text, IntWritable> {
	public void map(myKey k, myValue v, Context c) throws IOException, InterruptedException{
		String edu = v.getEducation().toString().trim();
		int age = Integer.parseInt(k.getage().toString().trim());
		int min= c.getConfiguration().getInt("min", 18);
		int max = c.getConfiguration().getInt("max", 50);
		if(age>=min&&age<=max){
			c.write(new Text(edu), new IntWritable(1));
		}
	}

}
