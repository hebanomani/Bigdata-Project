import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<myKey, myValue, Text, Text> {
	public void map(myKey k, myValue v, Context c) throws IOException, InterruptedException{
		int age =Integer.parseInt(k.getage().toString().trim());
		String gen = v.getGender().toString().trim();
		String edu = v.getEducation().toString().trim();
		int min = c.getConfiguration().getInt("min", 18);
		int max = c.getConfiguration().getInt("max", 50);
		int g = c.getConfiguration().getInt("gen", 1);
		String gender="";
		if(g==1)
			gender="Female";
		else
			gender="Male";
		if((age>=min && age<=max)&& gen.contains(gender)){
			c.write(new Text(edu), new Text("one"));
		}
		
	}

}
