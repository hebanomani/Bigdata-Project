import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer3 extends Reducer<Text, IntWritable, Text, NullWritable> {
	public void reduce(Text inpk, Iterable<IntWritable> inpv, Context c) throws IOException, InterruptedException{
		int cnt=0;
		for(IntWritable x: inpv){
			cnt++;
		}
		c.write(new Text(inpk+" : "+cnt), null);
	}

}
