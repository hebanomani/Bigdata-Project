import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper3 extends Mapper<myKey, myValue, Text, IntWritable> {
	public void map(myKey k, myValue v, Context c) throws IOException, InterruptedException{
		
	String tf =	v.getTaxFiler().toString().trim();
	String citizen =v.getCitiznshp().toString().trim();
	if(citizen.contains("Foreign born- Not a citizen of U S")){
		c.write(new Text(tf), new IntWritable(1));
	}
		
	}

}
