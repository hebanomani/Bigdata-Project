import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer2 extends Reducer<Text, DoubleWritable, Text, NullWritable> {
	public void reduce(Text inpk, Iterable<DoubleWritable> inpv, Context c) throws IOException, InterruptedException{
		double total = 0,avg=0;
		int cnt=0;
		for(DoubleWritable d: inpv){
			total+=d.get();
			cnt++;
		}
		avg=total/cnt;
		c.write(new Text(inpk+" "+avg), null);
	}

}
