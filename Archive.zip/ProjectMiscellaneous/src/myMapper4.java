import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper4 extends Mapper<myKey, myValue, Text, IntWritable>{
	public void map(myKey k, myValue v, Context c) throws IOException, InterruptedException{
		String cntry = v.getCob().toString().trim();
		String citizen = v.getCitiznshp().toString().trim();
		if(cntry.contains("United-States")){
			
		}
		else if(citizen.contains("Foreign born- U S citizen by naturalization")){
			c.write(new Text(cntry), new IntWritable(1));
		}
	}
}
