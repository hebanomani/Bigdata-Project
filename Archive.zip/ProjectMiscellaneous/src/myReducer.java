import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text, Text, Text, IntWritable> {
	public void reduce(Text inpk,Iterable<Text> inpv,Context c ) throws IOException, InterruptedException{
		int cnt=0,min,max,g;
		min = c.getConfiguration().getInt("min", 18);
		max = c.getConfiguration().getInt("max", 50);
		g = c.getConfiguration().getInt("gen", 1);
		String gender="";
		if(g==1)
			gender="Female";
		else
			gender="Male";
		for(Text each: inpv){
			cnt++;
		}
		c.write(new Text("The total number of "+ gender + " between "+min +" - "+max+" having education" +inpk), new IntWritable(cnt));
	}

}
