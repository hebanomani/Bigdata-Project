import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class myDriver {
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException, URISyntaxException{
		@SuppressWarnings("resource")
		Scanner src = new Scanner(System.in);
		System.out.println("Enter your choice : \n 1. Degree wise count for employability 1 \n 2. Customer Analysis ");
		System.out.println(" 3. Non US citizen- Tax Filer status \n 4.Total number of Foreign born- U S citizen by naturalization ");
		int ch= src.nextInt();
		int min,max,g;
		switch(ch){
		case 1: {
			Configuration conf = new Configuration();
			do{
			System.out.println("Enter minimum age : ");
			min = src.nextInt();
			System.out.println("Enter maximum age : ");
			max = src.nextInt();
			System.out.println("Select gender : \n1.Female \n2.Male ");
			g= src.nextInt();
			}while(min<18 || max>60 || g>2 ||g<1);
			conf.setInt("min", min);
			conf.setInt("max", max);
			conf.setInt("gen", g);
			Job j = new Job(conf, "Misc. Task 1");
			FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(myDriver.class);
			j.setMapperClass(myMapper.class);
			j.setReducerClass(myReducer.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(Text.class);
			j.setInputFormatClass(myInputFormat.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
		Path newpath = new Path(args[1]);
		if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
			Path localfilepath = new Path("/home/cloudera/Desktop/Misc/Task1");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, localfilepath);
			}
			break;
		}
		case 2:{
			Configuration conf = new Configuration();
			Job j = new Job(conf, "Misc. Task 2");
			FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(myDriver.class);
			j.setMapperClass(myMapper2.class);
			j.setReducerClass(myReducer2.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(DoubleWritable.class);
			j.setInputFormatClass(myInputFormat.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
			DistributedCache.addCacheFile(new URI("/user/cloudera/agegroup.dat"),j.getConfiguration());

		Path newpath = new Path(args[1]);
		if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
			Path localfilepath = new Path("/home/cloudera/Desktop/Misc/Task2");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, localfilepath);
			}
			break;
		}
		case 3:{
			Configuration conf = new Configuration();
			Job j = new Job(conf, "Misc. Task 3");
			FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(myDriver.class);
			j.setMapperClass(myMapper3.class);
			j.setReducerClass(myReducer3.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(IntWritable.class);
			j.setInputFormatClass(myInputFormat.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
		Path newpath = new Path(args[1]);
		if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
			Path localfilepath = new Path("/home/cloudera/Desktop/Misc/Task3");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, localfilepath);
			}
			break;
		}
		case 4:{
			Configuration conf = new Configuration();
			Job j = new Job(conf, "Misc. Task 4");
			FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(myDriver.class);
			j.setMapperClass(myMapper4.class);
			j.setReducerClass(myReducer3.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(IntWritable.class);
			j.setInputFormatClass(myInputFormat.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
		Path newpath = new Path(args[1]);
		if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
			Path localfilepath = new Path("/home/cloudera/Desktop/Misc/Task4");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, localfilepath);
			}
			break;
		}
		default:
			System.out.println("You have entered wrong choice!!");
		
		}	
	}
}
