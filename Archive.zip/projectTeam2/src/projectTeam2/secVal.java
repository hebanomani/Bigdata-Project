package projectTeam2;

public class secVal {
	int tax;
	
	secVal(int tax){
		this.tax= tax;
	}

	void setTax(int tax){
		this.tax= tax;
	}
	
	int getTax(){
		return tax;
	}

}
