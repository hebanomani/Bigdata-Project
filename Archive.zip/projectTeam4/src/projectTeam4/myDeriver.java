package projectTeam4;

import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class myDeriver {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Scanner src = new Scanner(System.in);
		System.out.println("Enter Choice : \n 1. Task 1 \n 2. Task 2 \n 3. Task 3 \n 4. Task 4");
		int ch= src.nextInt();
		Job j = new Job();
		int yrs,age;
		if(ch==1){
		do{	
		System.out.println("Enter the no of years after which the election will occur");
		yrs = src.nextInt();
		}while(yrs<0);
		Configuration conf = new Configuration();
		conf.setInt("years", yrs);
		j = new Job(conf,"Task 1");
		FileSystem hdfs = FileSystem.get(conf);
		//hdfs.mkdirs(newpath);
		j.setJarByClass(myDeriver.class);
		j.setMapperClass(myMapper1.class);
		j.setReducerClass(myReducer1.class);
		j.setNumReduceTasks(1);
		j.setMapOutputKeyClass(Text.class);
		j.setMapOutputValueClass(IntWritable.class);
		j.setInputFormatClass(myInputFormat.class);
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path (args[1]));
		Path newpath = new Path(args[1]);
		if(hdfs.exists(newpath)){
			hdfs.delete(newpath,true);
		}
		Path localfilepath = new Path("/home/cloudera/Desktop/Team4/Task1");
		if(j.waitForCompletion(true)){
			hdfs.copyToLocalFile(newpath, localfilepath);
		}
				
		}
		else if(ch==2){
			do{
			System.out.println("Enter the no of years after which the calculation has to be done");
			yrs = src.nextInt();
			System.out.println("Enter the no of age of senior citizen");
			age = src.nextInt();
			}while(yrs<0 || age<45);
			Configuration conf = new Configuration();
			conf.setInt("years", yrs);
			conf.setInt("age", age);
			j = new Job(conf,"Task 2");
			FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(myDeriver.class);
			j.setMapperClass(myMapper2.class);
			j.setReducerClass(myReducer1.class);
			j.setNumReduceTasks(1);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(IntWritable.class);
			j.setInputFormatClass(myInputFormat.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
			Path newpath = new Path(args[1]);
			if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, new Path("/home/cloudera/Desktop/Team4/task2"));
			}
		}
		else if(ch==3){
			Configuration conf = new Configuration();
			j = new Job(conf,"Task 3");
			FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(myDeriver.class);
			j.setMapperClass(myMapper3.class);
			j.setNumReduceTasks(0);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(Text.class);
			j.setInputFormatClass(myInputFormat.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
			Path newpath = new Path(args[1]);
			if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, new Path("/home/cloudera/Desktop/Team4/task3"));
			}
		}
		else if(ch==4){
			Configuration conf = new Configuration();
			j = new Job(conf,"Task 4");
			FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(myDeriver.class);
			j.setMapperClass(myMapper4.class);
			j.setNumReduceTasks(0);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(Text.class);
			j.setInputFormatClass(myInputFormat.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
			Path newpath = new Path(args[1]);
			if(hdfs.exists(newpath)){
				hdfs.delete(newpath, true);
			}
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, new Path("/home/cloudera/Desktop/Team4/task3"));
			}
		}
		else{
			System.out.println("Wrong choice");
		}
		
		
		
		//System.exit(j.waitForCompletion(true)?0:1);

	}

}
